we have implemented some methods in build.gradle for tag based selenium execution.

Purpose of method Implementation :

Here we are execute particular test cases by passing tags as parameters so it will 
executes specific tags based test cases in over al lselenium project.


Syntax :

Runner.bat Scenario tag name

Example : Runner.bat @toolQA

if we want to call gradel method directly in command prompt

gradle -Pa=@toolQA runAllTests