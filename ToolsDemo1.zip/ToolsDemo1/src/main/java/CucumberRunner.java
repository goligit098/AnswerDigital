import cucumber.api.CucumberOptions;
//import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
@Deprecated
//@RunWith(Cucumber.class)
//@CucumberOptions(plugin = {"html:target/cucumber-html-report"},features = {"src/main/resources/"},glue = {"com.ft","com.pt"})
@CucumberOptions(tags = {"~@pending"})
public class CucumberRunner {
}