package automation;

import automation.common.ScreenShotMaker;
import automation.config.Browser;

import automation.registration.StudentForm;
import io.cucumber.core.api.Scenario;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CucumberStepDef {
    protected WebDriver driver;
    private Browser google = new Browser(driver);
    ArrayList finaliList = new ArrayList();
    String result ;
    List<String> tooltip;
    StudentForm studentForm;
    ScreenShotMaker screenShotMaker =new ScreenShotMaker();
    @Before
    public void setUp() {
        driver = google.getBrowser();
        }

    @io.cucumber.java.en.Given("^User Logged into Tools QA Portal \"([^\"]*)\"$")
    public void user_Logged_into_Tools_QA_Portal(String arg1) throws Throwable {
        Thread.sleep(3000);
        google.openURL(arg1);
    }

    @Given("^Enter Student Registeation Form Details$")
    public void enter_Student_Registeation_Form_Details(DataTable dt) throws Throwable {
        List<Map<String, String>> liststoreValues = dt.asMaps(String.class, String.class);
        studentForm = PageFactory.initElements(driver,StudentForm.class);
        studentForm.sendStudentRegisteationDetails(liststoreValues,driver);
    }

    @When("^Submit Student Registration Form fileds$")
    public void submit_Student_Registration_Form_fileds() throws Throwable {
        studentForm = PageFactory.initElements(driver,StudentForm.class);
        result=studentForm.sendStudentRegisteationSubmit(driver);
        screenShotMaker.takeScreenShot(driver,"Registration");
    }

    @When("^Click on Drag and Drop Action$")
    public void click_on_Drag_and_Drop_Action() throws Throwable {
        studentForm = PageFactory.initElements(driver,StudentForm.class);
        studentForm.onClickDragAndDrop(driver);
        screenShotMaker.takeScreenShot(driver,"Drop and Drag");
    }

    @When("^Click on Tool Tip Demo$")
    public void click_on_tool_tip_demo() throws Throwable {
        studentForm = PageFactory.initElements(driver,StudentForm.class);
        tooltip=studentForm.onClickToolTip(driver);
        screenShotMaker.takeScreenShot(driver,"Tool Tips");
    }

    @When("^Click on Model Dialouge$")
    public void click_on_model_dialoguges() throws Throwable {
        studentForm = PageFactory.initElements(driver,StudentForm.class);
        studentForm.onModelDialogue(driver);
        screenShotMaker.takeScreenShot(driver,"Model Dialouges");
    }

    @When("^Click on Alert Page$")
    public void click_on_slert_page() throws Throwable {
        studentForm = PageFactory.initElements(driver,StudentForm.class);
        studentForm.onClickOnAlert(driver);
        screenShotMaker.takeScreenShot(driver,"Alert Pages");
    }

    @When("^Click on Date Pickers$")
    public void click_on_Date_Pickers() throws Throwable {
        studentForm = PageFactory.initElements(driver,StudentForm.class);
        studentForm.onClickOnDatePicker(driver);
        screenShotMaker.takeScreenShot(driver,"Date Pickers");
    }

    @Then("^Verify Form Data Success Value \"([^\"]*)\"$")
    public void verify_Form_Data_Success_Value(String arg1) throws Throwable {

        Assert.assertEquals(result,arg1);

    }

    @Then("^Verify Tooltip Value \"([^\"]*)\"$")
    public void Verify_Tooltip_Value(String arg1) throws Throwable {
        boolean value=false;
        for(String text:tooltip ) {
            if (text.equalsIgnoreCase(arg1)) {
                Assert.assertTrue(Boolean.TRUE);
                value=true;
            }
        }
        if(!value){
            Assert.assertFalse("Tooltip text is not matching",Boolean.TRUE);
        }
            }

    @Then("^Click on Close button$")
    public void click_on_Close_button() throws Throwable {

        driver.findElement(By.id("closeLargeModal")).click();

    }

    @Then("^close browser$")
    public void close_browser() throws Throwable {

        driver.quit();

    }
    @After
    @Deprecated
    public  void tearDown(Scenario scenario){
        scenario.embed(((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES),"image/png");
    }

}
