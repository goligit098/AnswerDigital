package automation.registration;

import com.google.common.base.Strings;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;


public class StudentForm {
    @FindBy(id = "firstName")
    private WebElement firstName;
    @FindBy(id = "lastName")
    private WebElement lastName;
    @FindBy(xpath = "//input[@id='gender-radio-1']")
    private WebElement maleGneder;
    @FindBy(xpath = "//input[@id='gender-radio-2']")
    private WebElement femaleGneder;
    @FindBy(xpath = "//input[@id='gender-radio-3']")
    private WebElement otherGender;
    @FindBy(id = "userNumber")
    private WebElement userNumber;
    @FindBy(xpath = "//*[@id=\"uploadPicture\"]")
    private WebElement uploadPicture;
    @FindBy(name = "gender")
    private WebElement gender;

    @FindBy(xpath = "//[*id='content']iframe")
    private WebElement picker;

    @FindBy(xpath = "//*[@id=\"submit\"]")
    private WebElement submit;

    @FindBy(xpath = "//div/input[@id='gender-radio-1']")
    private WebElement radio;
    @FindBy(id = "gender-radio-1")
    private WebElement sex;

    @FindBy(xpath = "//div[@id='draggable']")
    private WebElement draggable;

    @FindBy(xpath = "//div[@id='droppable']")
    private WebElement droppable;

    @FindBy(xpath = "//*[@id=\"example-modal-sizes-title-lg\"]")
    private WebElement resultText;

    @FindBy(xpath = "//div[contains(text(),'Practice Form')]")
    private WebElement failure;

    @FindBy(xpath = "//*[@id=\"datePickerMonthYearInput\"]")
    private WebElement DateText;

    @FindBy(xpath = "//select[@class='react-datepicker__month-select']")
    private WebElement monthselect;

    @FindBy(xpath = "//select[@class='react-datepicker__year-select']")
    private WebElement year;

    @FindBy(xpath = "//div[not(contains(@class,'outside-month')) and text()='29']")
    private WebElement dateValue;

    @FindBy (xpath ="//*[@id=\"uploadPicture\"]")
    private WebElement image;

    @FindBy (xpath ="//button[@id='toolTipButton']")
    private WebElement tooltipbut;

    @FindBy (xpath ="//div[text()='You hovered over the Button']")
    private WebElement tooltipbutdata;

    @FindBy (xpath ="//input[@id='toolTipTextField']")
    private WebElement tooltiptxt;

    @FindBy(xpath ="//div[text()='You hovered over the text field']")
    private WebElement Hovermetesttooltip;

    @FindBy (xpath ="//button[@id='showSmallModal']")
    private WebElement smmodal;

    @FindBy (xpath ="//*[@id=\"closeSmallModal\"]")
    private WebElement smmodalclose;

    @FindBy (xpath ="//button[@id='timerAlertButton']")
    private WebElement timeralert;

    static int count ;
    String formStatus = null;
    public void sendStudentRegisteationDetails(List<Map<String, String>> liststoreValues, WebDriver driver) throws InterruptedException {
            Thread.sleep(3000);
        WebElement ele;
        for (Map<String, String> residenceScreen : liststoreValues) {
            if (!Strings.isNullOrEmpty(residenceScreen.get("First Name"))) {
                enterValueInTextBox(firstName, residenceScreen.get("First Name"));
                count++;
            }
            if (!Strings.isNullOrEmpty(residenceScreen.get("Last Name"))) {
                enterValueInTextBox(lastName, residenceScreen.get("Last Name"));
                count++;
            }
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            if (!Strings.isNullOrEmpty(residenceScreen.get("Gender"))) {
                if (residenceScreen.get("Gender").equalsIgnoreCase("Male")) {
                    ele = maleGneder;
                } else if (residenceScreen.get("Gender").equalsIgnoreCase("Female")) {
                    ele = femaleGneder;
                } else {
                    ele = otherGender;
                }
                jse.executeScript("arguments[0].click()", ele);
                count++;
            }
            if (!Strings.isNullOrEmpty(residenceScreen.get("Mobile"))) {
                enterValueInTextBox(userNumber, residenceScreen.get("Mobile"));
                count++;
            }
            image.sendKeys(System.getProperty("user.dir")+"/images/ramcheran.JPG");
                                }
            }

    public static void enterValueInTextBox(WebElement textBox, String valueToEnter) {
        Wait(1000);
        if (!valueToEnter.isEmpty()) {
            textBox.clear();
            textBox.sendKeys(valueToEnter);
        }
    }

    public static void Wait(long miliSeconds) {
        try {
            Thread.sleep(miliSeconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    public static void selectRadioButtonValue(List<WebElement> radioButtonList, String radioValueToSelect) {
        if (!radioValueToSelect.isEmpty()) {
            int radioButtonCount = radioButtonList.size();
            for (int radioCount = 0; radioCount < radioButtonCount; radioCount++) {
                WebElement parentElement = radioButtonList.get(radioCount).findElement(By.xpath("./.."));
                String radioValue = radioButtonList.get(radioCount).getAttribute("value");
                String parentElementValue = parentElement.getText().trim();
                if (radioValue.equalsIgnoreCase(radioValueToSelect) || parentElementValue.equalsIgnoreCase(radioValueToSelect) || parentElementValue.toUpperCase().contains(radioValueToSelect.toUpperCase())) {
                    if (radioButtonList.get(radioCount).isEnabled()) {
                        radioButtonList.get(radioCount).sendKeys(Keys.SPACE);
                    }
                    break;
                }
            }
        }
    }

    public void onClickDragAndDrop(WebDriver driver) {
        Actions action = new Actions(driver);
        action.dragAndDrop(draggable, droppable).perform();
    }

    public List<String> onClickToolTip(WebDriver driver) {
        List<String> tooltipstests= new ArrayList<>();
        Actions actions = new Actions(driver);
        actions.moveToElement(tooltipbut).perform();
        tooltipstests.add(tooltipbutdata.getText());
        actions.moveToElement(tooltiptxt).perform();
        tooltipstests.add(Hovermetesttooltip.getText());
        return tooltipstests;
    }

    public void onModelDialogue(WebDriver driver) {
        smmodal.click();
        smmodalclose.click();
    }

    public void onClickOnAlert(WebDriver driver) {
        timeralert.click();
        WebDriverWait wait = new WebDriverWait(driver,6);
        wait.until(ExpectedConditions.alertIsPresent());
        Alert timealert = driver.switchTo().alert();
        timealert.accept();
    }

    public static void waitUntilID(String inputElement, WebDriver driver) {
        try {
            WebDriverWait waitFor = new WebDriverWait(driver, 60);
            waitFor.until(ExpectedConditions.visibilityOfElementLocated(By.id(inputElement)));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onClickOnDatePicker(WebDriver driver) throws InterruptedException {
        DateText.click();
        Calendar c1 = Calendar.getInstance();
        c1.add(Calendar.MONTH, 1);
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MMMM-dd");
        Date resultDate = c1.getTime();
        String dueDate = df.format(resultDate);
        String[] newDates = dueDate.split("-");
        selectValueForDropdownByVisibleText(monthselect, newDates[1]);
        selectValueForDropdownByVisibleText(year, newDates[0]);
        driver.findElement(By.xpath("//div[not(contains(@class,'outside-month')) and text()=" + newDates[2] + "]")).click();
        Thread.sleep(3000);
    }

    public static void selectValueForDropdownByVisibleText(WebElement dropDown, String valueToSelect) {
        Wait(1000);
        Select dropdownSelect = new Select(dropDown);
        dropdownSelect.selectByVisibleText(valueToSelect);

    }

    public String sendStudentRegisteationSubmit(WebDriver driver) throws InterruptedException {
        WebElement sube = submit;
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        System.out.println("Count1"+ count);

        jse.executeScript("arguments[0].click()", sube);
        if (count >= 4) {
            formStatus = resultText.getText();
            Thread.sleep(3000);
            driver.findElement(By.id("closeLargeModal")).click();
        } else {
            formStatus = failure.getText();
        }
        return formStatus;
    }

}